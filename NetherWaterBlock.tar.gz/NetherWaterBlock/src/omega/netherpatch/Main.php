<?php

declare(strict_types=1);

namespace omega\netherpatch;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as TF;

class Main extends PluginBase {

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents(new NetherWaterListener($this), $this);
        $this->getLogger()->info(TF::GREEN . "Protection anti-eau Nether activée !");
    }
}
