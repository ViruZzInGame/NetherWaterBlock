<?php

declare(strict_types=1);

namespace omega\netherpatch;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\block\Water;
use pocketmine\block\Ice;
use pocketmine\block\PackedIce;
use pocketmine\block\BlueIce;
use pocketmine\block\Snow;
use pocketmine\block\SnowLayer;
use pocketmine\block\CaveVines;
use pocketmine\item\Item;
use pocketmine\item\Bucket;
use pocketmine\item\VanillaItems;
use pocketmine\world\World;

class NetherWaterListener implements Listener {

    private array  $worlds;
    private string $message;
    private bool   $enabled;

    /**
     * Noms d'items (en minuscule) dont le placement doit être bloqué.
     * Inclut tous les seaux contenant de l'eau ou une entité aquatique,
     * détectés par correspondance de nom car PM5 n'a pas de classe
     * dédiée pour chaque variante (axolotl, têtard, poissons...).
     */
    private const BLOCKED_ITEM_NAMES = [
        'water bucket',
        'water_bucket',
        'seau d\'eau',
        'axolotl bucket',
        'axolotl_bucket',
        'seau d\'axolotl',
        'tadpole bucket',
        'tadpole_bucket',
        'seau de têtard',
        'seau de tetard',
        'cod bucket',
        'cod_bucket',
        'salmon bucket',
        'salmon_bucket',
        'tropical fish bucket',
        'tropical_fish_bucket',
        'pufferfish bucket',
        'pufferfish_bucket',
        'powder snow bucket',
        'powder_snow_bucket',
        'seau de neige poudreuse',
    ];

    public function __construct(private Main $plugin) {
        $cfg           = $plugin->getConfig();
        $this->enabled = (bool)   $cfg->get("enabled", true);
        $this->message = (string) $cfg->get("message", "§cL'eau s'évapore instantanément dans le Nether !");
        $worlds        = $cfg->get("worlds", []);
        $this->worlds  = is_array($worlds) ? $worlds : [];
    }

    // ============================================================
    //  DÉTECTION DU MONDE NETHER
    // ============================================================

    private function isNetherWorld(World $world): bool {
        if (!$this->enabled) return false;

        if (!empty($this->worlds)) {
            return in_array($world->getFolderName(), $this->worlds, true);
        }

        $name = strtolower($world->getFolderName());
        return str_contains($name, "nether") || str_contains($name, "hell");
    }

    // ============================================================
    //  DÉTECTION D'ITEM AQUATIQUE (seau d'eau et variantes)
    // ============================================================

    private function isWaterItem(Item $item): bool {
        // Classe Bucket avec contenu eau (PM5 natif)
        if ($item instanceof Bucket) {
            if ($item->equals(VanillaItems::WATER_BUCKET(), false, false)) {
                return true;
            }
        }

        // Détection par nom de l'item (couvre axolotl, têtard, poissons,
        // neige poudreuse, et tout bucket aquatique custom)
        $name = strtolower($item->getName());
        foreach (self::BLOCKED_ITEM_NAMES as $blocked) {
            if (str_contains($name, $blocked)) {
                return true;
            }
        }

        // Détection par l'identifiant réseau (namespace:id)
        // Couvre les items Bedrock non mappés par PM5 (axolotl_bucket, etc.)
        try {
            $typeId = strtolower($item->getTypeId());
        } catch (\Throwable) {
            $typeId = "";
        }

        // Détection via NBT custom name ou identifier tag
        $nbt = $item->getNamedTag();
        if ($nbt->getTag("minecraft:item") !== null) {
            // item custom avec tag de type
        }

        return false;
    }

    // ============================================================
    //  DÉTECTION DE BLOC GÉNÉRANT DE L'EAU
    // ============================================================

    private function isWaterBlock(\pocketmine\block\Block $block): bool {
        return $block instanceof Water
            || $block instanceof Ice
            || $block instanceof PackedIce
            || $block instanceof BlueIce
            || $block instanceof Snow      // La neige fond en eau
            || $block instanceof SnowLayer;
    }

    // ============================================================
    //  EVENTS
    // ============================================================

    /** Seau utilisé directement (clic dans l'air ou sur un bloc) */
    public function onItemUse(PlayerItemUseEvent $event): void {
        $player = $event->getPlayer();
        if (!$this->isNetherWorld($player->getWorld())) return;

        if ($this->isWaterItem($event->getItem())) {
            $event->cancel();
            $player->sendPopup($this->message);
        }
    }

    /** Clic droit sur un bloc avec un seau */
    public function onInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        if (!$this->isNetherWorld($player->getWorld())) return;
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;

        if ($this->isWaterItem($event->getItem())) {
            $event->cancel();
            $player->sendPopup($this->message);
        }
    }

    /** Placement de bloc eau/glace/neige */
    public function onBlockPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        if (!$this->isNetherWorld($player->getWorld())) return;

        foreach ($event->getTransaction()->getBlocks() as [$bx, $by, $bz, $block]) {
            if ($this->isWaterBlock($block)) {
                $event->cancel();
                $player->sendPopup($this->message);
                return;
            }
        }

        // Bloquer aussi si l'item tenu est un seau aquatique
        // (cas où PM5 ne mappe pas le bloc mais l'item est reconnu)
        if ($this->isWaterItem($event->getItem())) {
            $event->cancel();
            $player->sendPopup($this->message);
        }
    }
}
